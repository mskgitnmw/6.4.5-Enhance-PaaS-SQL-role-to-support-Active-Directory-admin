# azure-role-mssql

## Synopsis
Ansible role for creating paas SQL database.

## Azure Service
This role supports the Azure Core Services.

More information can be found here: http://project.nml.com/sites/IN001797/eac/_layouts/15/start.aspx#/WIKIAZURE/Catalog%20of%20Services%20Offered.aspx.

## Requirements
This role requires Azure CLI version 2.0.

## Assumptions
None

## Variables

## Role Variables

| parameter name       | required? | default | choices | comments |
| -------------------- | --------- | ------- | ------- | --------------------------------------------------------------- |
| state              | yes  | False      | present,absent      | when it is present new database or server will be created.If it is absent , the database or the server will be deleted |
|resource_group|yes|none|none|Based on resource group in which the paas SQL database needs to be deployed|

## Databases Variables

| parameter name       | required? | default | choices | comments |
| -------------------- | --------- | ------- | ------- | --------------------------------------------------------------- |
| servername              | yes  | none  | none  | specify the server name in which the database needs to be created.It should be unique. |
|serveradmin| yes|none|none|specify the user name with which you are trying to login to the server.|
|password|yes| none|none| specify the password for the user name with which you are trying to login to the server.your password cannot contain all or part of the login name.part of a login name is defined as three or more consecutive alphanumeric characters.|
|dblist|optional|none|Either specify the database to be deleted or only if the server has to be deleted, need not specify the database name|specify the list of database that needs to be created in the server.For deletion of server this is optional.|
|location|yes|none|any valid location|specify the location where you need to create the sql database.|
|collation|yes|none|any valid collation|specify the collation with which database needs to be created.|
|edition|yes|none|Basic,standard,premium|Basic - For infrequent access and less demanding workloads,Standard-For most production workloads,Premium-For IO- and compute-intensive workloads.|
|serviceobjectivename|yes|none|For Basic edition - Basic,For Standard edition - S0,S1,S2,S3 , For premium edition - P1,P2,P4,P6,P11,P15 |This is certain level of resources for a single database for providing a predictable level of performance. Based on DTUs the resource will be allocated.|
|maxsizeingb|yes|none|For Basic edition - 0.1,0.5,1,2 ,For Standard Edition - 0.1,0.5,1,2,5,10,20,30,40,50,100,150,200,250, For premium edition - 0.1,0.5,1,2,5,10,20,30,40,50,100,150,200,250| This is the maximum storage. By default the role assumes that the values are mentioned in GB.The input should be in GB.|


## Example playbooks
my_playbook.yml:

```
- name: create paas sql database
  hosts: localhost
  vars_files:
    - vars/sqlvars.yml
  roles:
    - paas
```
sqlvars.yml:

```
  resource_group: sandhya_lab
  state: absent
  sql:
    - servername: "sandhyaserver"
      serveradmin: "sandhyauser"
      password: "SandhyaTest@123"
      dblist:
        - test1
        - test2
      location: "eastus"
      collation: "SQL_Latin1_General_CP1_CI_AS"
      edition: "standard"
      serviceobjectivename: "s1"
      maxsizeingb: "250"

```
requirements.yml

```
- src: git@github.nml.com:nm/azure-role-mssql.git
  scm: git
  version: v1.1.0
  name: paas

```
## Notes

1> dblist in the vars file should be listed one after the other as shown in the above example.

2> The value for maxsizeingb is always considered in GB.

3>Check the valid parameters for serviceobjectivename and maxsizeingb in Database parameters table.

## Version Support Status
1.1.0
